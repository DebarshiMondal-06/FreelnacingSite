
<?php

class config {
	
	
	const SMTP_HOST = 'smtp.gmail.com';
	
	const SMTP_PORT = 587;
	
	const SMTP_USER = 'debarshimondal121@gmail.com';
	
	const SMTP_PASSWORD = 'mondal@1999';
}




?>